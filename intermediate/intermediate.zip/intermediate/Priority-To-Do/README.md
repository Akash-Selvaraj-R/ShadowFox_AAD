# To-Do List App with Priority Sorting

### Description

A minimalist to-do list web app built with HTML, CSS, and JavaScript, allowing users to add, delete, and mark tasks as complete, with priority sorting to organize tasks by importance and a responsive design.

### Tech Stack


Frontend: HTML, CSS, JavaScript

### License

This project is licensed under the MIT License. See the LICENSE file for details.

### Contact

For questions or feedback, reach out to Akash Selvaraj or open an issue on GitHub
