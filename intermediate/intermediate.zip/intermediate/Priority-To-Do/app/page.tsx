"use client"

import { useState, useEffect } from "react"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

// Define the Task type
type Priority = "high" | "medium" | "low"

interface Task {
  id: string
  text: string
  completed: boolean
  priority: Priority
  createdAt: number
}

export default function TodoApp() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTaskText, setNewTaskText] = useState("")
  const [newTaskPriority, setNewTaskPriority] = useState<Priority>("medium")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc")

  // Load tasks from localStorage on initial render
  useEffect(() => {
    const savedTasks = localStorage.getItem("tasks")
    if (savedTasks) {
      setTasks(JSON.parse(savedTasks))
    }
  }, [])

  // Save tasks to localStorage whenever tasks change
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks))
  }, [tasks])

  // Add a new task
  const addTask = () => {
    if (newTaskText.trim() === "") return

    const newTask: Task = {
      id: crypto.randomUUID(),
      text: newTaskText,
      completed: false,
      priority: newTaskPriority,
      createdAt: Date.now(),
    }

    setTasks([...tasks, newTask])
    setNewTaskText("")
    setNewTaskPriority("medium")
  }

  // Toggle task completion status
  const toggleTaskCompletion = (id: string) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)))
  }

  // Delete a task
  const deleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id))
  }

  // Update task priority
  const updateTaskPriority = (id: string, priority: Priority) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, priority } : task)))
  }

  // Sort tasks by priority
  const sortedTasks = [...tasks].sort((a, b) => {
    const priorityValues = { high: 3, medium: 2, low: 1 }
    const priorityA = priorityValues[a.priority]
    const priorityB = priorityValues[b.priority]

    return sortOrder === "desc" ? priorityB - priorityA : priorityA - priorityB
  })

  // Get priority badge color
  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case "high":
        return "bg-red-500 hover:bg-red-600"
      case "medium":
        return "bg-yellow-500 hover:bg-yellow-600"
      case "low":
        return "bg-green-500 hover:bg-green-600"
      default:
        return "bg-slate-500"
    }
  }

  return (
    <main className="container max-w-2xl mx-auto p-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Priority Todo List</h1>

      {/* Add new task form */}
      <div className="flex flex-col gap-4 mb-8">
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Add a new task..."
            value={newTaskText}
            onChange={(e) => setNewTaskText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") addTask()
            }}
            className="flex-1"
          />
          <Select value={newTaskPriority} onValueChange={(value) => setNewTaskPriority(value as Priority)}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={addTask}>
            <Plus className="mr-2 h-4 w-4" /> Add
          </Button>
        </div>

        {/* Sort controls */}
        <div className="flex justify-between items-center">
          <div className="text-sm text-muted-foreground">
            {tasks.length} {tasks.length === 1 ? "task" : "tasks"}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm">Sort by priority:</span>
            <Select value={sortOrder} onValueChange={(value) => setSortOrder(value as "asc" | "desc")}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="desc">High to Low</SelectItem>
                <SelectItem value="asc">Low to High</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Task list */}
      <div className="space-y-3">
        {sortedTasks.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">No tasks yet. Add a task to get started!</div>
        ) : (
          sortedTasks.map((task) => (
            <Card key={task.id} className={task.completed ? "opacity-70" : ""}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-3 flex-1">
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() => toggleTaskCompletion(task.id)}
                      id={`task-${task.id}`}
                    />
                    <label
                      htmlFor={`task-${task.id}`}
                      className={`flex-1 ${task.completed ? "line-through text-muted-foreground" : ""}`}
                    >
                      {task.text}
                    </label>
                  </div>

                  <div className="flex items-center gap-2">
                    <Select
                      value={task.priority}
                      onValueChange={(value) => updateTaskPriority(task.id, value as Priority)}
                    >
                      <SelectTrigger className="h-8 w-[100px]">
                        <Badge className={`${getPriorityColor(task.priority)} text-white`}>
                          {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                        </Badge>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="destructive" size="sm" onClick={() => deleteTask(task.id)}>
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </main>
  )
}
