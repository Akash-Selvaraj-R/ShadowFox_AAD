"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, MapPin, Thermometer } from "lucide-react"

// Mock weather data
const weatherData = {
  Chennai: {
    current: { temp: 34, condition: "Sunny" },
    forecast: [
      { day: "Tomorrow", temp: 33, condition: "Cloudy" },
      { day: "Day 2", temp: 32, condition: "Rainy" },
      { day: "Day 3", temp: 31, condition: "Sunny" },
    ],
  },
  Mumbai: {
    current: { temp: 30, condition: "Rainy" },
    forecast: [
      { day: "Tomorrow", temp: 29, condition: "Rainy" },
      { day: "Day 2", temp: 28, condition: "Cloudy" },
      { day: "Day 3", temp: 27, condition: "Rainy" },
    ],
  },
  Delhi: {
    current: { temp: 28, condition: "Cloudy" },
    forecast: [
      { day: "Tomorrow", temp: 30, condition: "Sunny" },
      { day: "Day 2", temp: 32, condition: "Sunny" },
      { day: "Day 3", temp: 29, condition: "Cloudy" },
    ],
  },
  Bangalore: {
    current: { temp: 25, condition: "Cloudy" },
    forecast: [
      { day: "Tomorrow", temp: 26, condition: "Rainy" },
      { day: "Day 2", temp: 24, condition: "Cloudy" },
      { day: "Day 3", temp: 27, condition: "Sunny" },
    ],
  },
  Kolkata: {
    current: { temp: 32, condition: "Rainy" },
    forecast: [
      { day: "Tomorrow", temp: 31, condition: "Rainy" },
      { day: "Day 2", temp: 30, condition: "Cloudy" },
      { day: "Day 3", temp: 33, condition: "Sunny" },
    ],
  },
  Hyderabad: {
    current: { temp: 35, condition: "Sunny" },
    forecast: [
      { day: "Tomorrow", temp: 36, condition: "Sunny" },
      { day: "Day 2", temp: 34, condition: "Cloudy" },
      { day: "Day 3", temp: 33, condition: "Rainy" },
    ],
  },
}

// Weather icon mapping
const getWeatherIcon = (condition: string) => {
  switch (condition.toLowerCase()) {
    case "sunny":
      return "☀️"
    case "rainy":
      return "🌧️"
    case "cloudy":
      return "☁️"
    default:
      return "🌤️"
  }
}

// Weather condition color mapping
const getConditionColor = (condition: string) => {
  switch (condition.toLowerCase()) {
    case "sunny":
      return "text-yellow-600"
    case "rainy":
      return "text-blue-600"
    case "cloudy":
      return "text-gray-600"
    default:
      return "text-gray-500"
  }
}

export default function WeatherApp() {
  const [city, setCity] = useState("")
  const [weather, setWeather] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [searchedCity, setSearchedCity] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!city.trim()) return

    setLoading(true)
    setError("")
    setWeather(null)

    // Simulate API call delay
    setTimeout(() => {
      const cityKey = Object.keys(weatherData).find((key) => key.toLowerCase() === city.toLowerCase())

      if (cityKey) {
        setWeather(weatherData[cityKey as keyof typeof weatherData])
        setSearchedCity(cityKey)
        setError("")
      } else {
        setError("Sorry, no data available for this city.")
        setWeather(null)
        setSearchedCity("")
      }
      setLoading(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-8">
          <h1 className="text-4xl font-bold text-white mb-2">Weather Forecast</h1>
          <p className="text-blue-100">Get weather information for your city</p>
        </div>

        {/* Search Form */}
        <Card className="mb-8 shadow-lg">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="flex gap-4">
              <div className="flex-1">
                <Input
                  type="text"
                  placeholder="Enter city name (e.g., Chennai, Mumbai, Delhi)"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="text-lg"
                  disabled={loading}
                />
              </div>
              <Button type="submit" disabled={loading || !city.trim()} className="px-8">
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Searching...
                  </>
                ) : (
                  "Get Weather"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Available Cities Info */}
        <div className="mb-6 text-center">
          <p className="text-blue-100 text-sm">
            Available cities: Chennai, Mumbai, Delhi, Bangalore, Kolkata, Hyderabad
          </p>
        </div>

        {/* Loading State */}
        {loading && (
          <Card className="mb-8 shadow-lg">
            <CardContent className="p-8 text-center">
              <Loader2 className="w-8 h-8 mx-auto mb-4 animate-spin text-blue-600" />
              <p className="text-gray-600">Fetching weather data...</p>
            </CardContent>
          </Card>
        )}

        {/* Error State */}
        {error && (
          <Card className="mb-8 shadow-lg border-red-200">
            <CardContent className="p-6 text-center">
              <div className="text-red-500 text-xl mb-2">❌</div>
              <p className="text-red-600 font-medium">{error}</p>
              <p className="text-gray-500 text-sm mt-2">
                Try searching for: Chennai, Mumbai, Delhi, Bangalore, Kolkata, or Hyderabad
              </p>
            </CardContent>
          </Card>
        )}

        {/* Weather Display */}
        {weather && !loading && (
          <div className="space-y-6">
            {/* Current Weather */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <MapPin className="w-6 h-6 text-blue-600" />
                  Current Weather in {searchedCity}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="text-6xl">{getWeatherIcon(weather.current.condition)}</div>
                    <div>
                      <div className="text-4xl font-bold text-gray-800">{weather.current.temp}°C</div>
                      <div className={`text-lg font-medium ${getConditionColor(weather.current.condition)}`}>
                        {weather.current.condition}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <Thermometer className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-500 text-sm">Current Temperature</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 3-Day Forecast */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">3-Day Forecast</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {weather.forecast.map((day: any, index: number) => (
                    <Card key={index} className="border-2 hover:shadow-md transition-shadow">
                      <CardContent className="p-4 text-center">
                        <div className="text-lg font-semibold text-gray-800 mb-2">{day.day}</div>
                        <div className="text-4xl mb-3">{getWeatherIcon(day.condition)}</div>
                        <div className="text-2xl font-bold text-gray-800 mb-1">{day.temp}°C</div>
                        <div className={`text-sm font-medium ${getConditionColor(day.condition)}`}>{day.condition}</div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-12 pb-8">
          <p className="text-blue-100 text-sm">Weather data is simulated for demonstration purposes</p>
        </div>
      </div>
    </div>
  )
}
