"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Trash2, History } from "lucide-react"

// Interface for calculation history entries
interface HistoryEntry {
  id: number
  expression: string
  result: string
  timestamp: Date
}

export default function AdvancedCalculator() {
  // State management for calculator functionality
  const [display, setDisplay] = useState("0")
  const [previousValue, setPreviousValue] = useState<number | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)
  const [history, setHistory] = useState<HistoryEntry[]>([])
  const [showHistory, setShowHistory] = useState(false)
  const [expression, setExpression] = useState("")

  /**
   * Handle number input from buttons or keyboard
   * @param num - The number string to input
   */
  const inputNumber = useCallback(
    (num: string) => {
      if (waitingForOperand) {
        setDisplay(num)
        setWaitingForOperand(false)
      } else {
        setDisplay(display === "0" ? num : display + num)
      }
    },
    [display, waitingForOperand],
  )

  /**
   * Handle decimal point input
   */
  const inputDecimal = useCallback(() => {
    if (waitingForOperand) {
      setDisplay("0.")
      setWaitingForOperand(false)
    } else if (display.indexOf(".") === -1) {
      setDisplay(display + ".")
    }
  }, [display, waitingForOperand])

  /**
   * Perform basic arithmetic calculations
   * @param firstValue - First operand
   * @param secondValue - Second operand
   * @param operation - Operation to perform
   * @returns Calculation result
   */
  const calculate = (firstValue: number, secondValue: number, operation: string): number => {
    switch (operation) {
      case "+":
        return firstValue + secondValue
      case "-":
        return firstValue - secondValue
      case "*":
        return firstValue * secondValue
      case "/":
        if (secondValue === 0) {
          throw new Error("Cannot divide by zero")
        }
        return firstValue / secondValue
      case "^":
        return Math.pow(firstValue, secondValue)
      default:
        return secondValue
    }
  }

  /**
   * Handle operation input (+, -, *, /, ^)
   * @param nextOperation - The operation to set
   */
  const inputOperation = useCallback(
    (nextOperation: string) => {
      const inputValue = Number.parseFloat(display)

      if (isNaN(inputValue)) {
        setDisplay("Error")
        return
      }

      if (previousValue === null) {
        setPreviousValue(inputValue)
        setExpression(display + " " + nextOperation + " ")
      } else if (operation) {
        try {
          const currentValue = previousValue || 0
          const newValue = calculate(currentValue, inputValue, operation)

          if (!isFinite(newValue)) {
            throw new Error("Invalid calculation")
          }

          setDisplay(String(newValue))
          setPreviousValue(newValue)
          setExpression(expression + display + " " + nextOperation + " ")
        } catch (error) {
          setDisplay("Error")
          setPreviousValue(null)
          setOperation(null)
          setExpression("")
          return
        }
      }

      setWaitingForOperand(true)
      setOperation(nextOperation)
    },
    [display, previousValue, operation, expression],
  )

  /**
   * Handle advanced operations (√, %, ±)
   * @param advancedOp - The advanced operation to perform
   */
  const inputAdvancedOperation = useCallback(
    (advancedOp: string) => {
      const inputValue = Number.parseFloat(display)

      if (isNaN(inputValue)) {
        setDisplay("Error")
        return
      }

      try {
        let result: number
        let expr: string

        switch (advancedOp) {
          case "√":
            if (inputValue < 0) {
              throw new Error("Cannot calculate square root of negative number")
            }
            result = Math.sqrt(inputValue)
            expr = `√(${inputValue})`
            break
          case "%":
            result = inputValue / 100
            expr = `${inputValue}%`
            break
          case "±":
            result = -inputValue
            expr = `±(${inputValue})`
            break
          default:
            return
        }

        if (!isFinite(result)) {
          throw new Error("Invalid calculation")
        }

        // Add to history
        addToHistory(expr, String(result))

        setDisplay(String(result))
        setWaitingForOperand(true)
        setPreviousValue(null)
        setOperation(null)
        setExpression("")
      } catch (error) {
        setDisplay("Error")
      }
    },
    [display],
  )

  /**
   * Perform the final calculation when equals is pressed
   */
  const performCalculation = useCallback(() => {
    const inputValue = Number.parseFloat(display)

    if (previousValue !== null && operation && !isNaN(inputValue)) {
      try {
        const newValue = calculate(previousValue, inputValue, operation)

        if (!isFinite(newValue)) {
          throw new Error("Invalid calculation")
        }

        const fullExpression = expression + display
        addToHistory(fullExpression, String(newValue))

        setDisplay(String(newValue))
        setPreviousValue(null)
        setOperation(null)
        setWaitingForOperand(true)
        setExpression("")
      } catch (error) {
        setDisplay("Error")
        setPreviousValue(null)
        setOperation(null)
        setExpression("")
      }
    }
  }, [display, previousValue, operation, expression])

  /**
   * Add calculation to history
   * @param expr - The expression that was calculated
   * @param result - The result of the calculation
   */
  const addToHistory = (expr: string, result: string) => {
    const newEntry: HistoryEntry = {
      id: Date.now(),
      expression: expr,
      result: result,
      timestamp: new Date(),
    }
    setHistory((prev) => [newEntry, ...prev].slice(0, 50)) // Keep only last 50 entries
  }

  /**
   * Clear the display only
   */
  const clearDisplay = useCallback(() => {
    setDisplay("0")
    setPreviousValue(null)
    setOperation(null)
    setWaitingForOperand(false)
    setExpression("")
  }, [])

  /**
   * Clear both display and history
   */
  const clearAll = useCallback(() => {
    clearDisplay()
    setHistory([])
  }, [clearDisplay])

  /**
   * Handle keyboard input
   */
  const handleKeyPress = useCallback(
    (event: KeyboardEvent) => {
      const { key } = event

      // Prevent default behavior for calculator keys
      if (/[0-9+\-*/.=]/.test(key) || key === "Enter" || key === "Escape" || key === "Backspace") {
        event.preventDefault()
      }

      // Number keys
      if (/[0-9]/.test(key)) {
        inputNumber(key)
      }
      // Decimal point
      else if (key === ".") {
        inputDecimal()
      }
      // Operations
      else if (key === "+") {
        inputOperation("+")
      } else if (key === "-") {
        inputOperation("-")
      } else if (key === "*") {
        inputOperation("*")
      } else if (key === "/") {
        inputOperation("/")
      }
      // Equals or Enter
      else if (key === "=" || key === "Enter") {
        performCalculation()
      }
      // Clear
      else if (key === "Escape" || key === "c" || key === "C") {
        clearDisplay()
      }
      // Backspace
      else if (key === "Backspace") {
        if (display.length > 1) {
          setDisplay(display.slice(0, -1))
        } else {
          setDisplay("0")
        }
      }
    },
    [inputNumber, inputDecimal, inputOperation, performCalculation, clearDisplay, display],
  )

  // Set up keyboard event listeners
  useEffect(() => {
    document.addEventListener("keydown", handleKeyPress)
    return () => {
      document.removeEventListener("keydown", handleKeyPress)
    }
  }, [handleKeyPress])

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Calculator */}
        <div className="lg:col-span-2">
          <Card className="shadow-2xl">
            <CardHeader className="pb-4">
              <CardTitle className="text-center text-2xl font-bold text-gray-800">Advanced Calculator</CardTitle>
              {/* Display Screen */}
              <div className="bg-gray-900 text-white p-6 rounded-lg">
                {/* Expression display */}
                {expression && <div className="text-sm text-gray-400 mb-2 font-mono">{expression}</div>}
                {/* Main display */}
                <div className="text-right text-4xl font-mono font-bold min-h-[4rem] flex items-center justify-end overflow-hidden">
                  {display}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-5 gap-3">
                {/* First Row - Advanced Operations */}
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
                  onClick={() => inputAdvancedOperation("√")}
                >
                  √
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
                  onClick={() => inputOperation("^")}
                >
                  x^y
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
                  onClick={() => inputAdvancedOperation("%")}
                >
                  %
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-red-50 hover:bg-red-100 text-red-700 border-red-200"
                  onClick={clearDisplay}
                >
                  C
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-red-50 hover:bg-red-100 text-red-700 border-red-200"
                  onClick={clearAll}
                >
                  AC
                </Button>

                {/* Second Row */}
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
                  onClick={() => inputAdvancedOperation("±")}
                >
                  ±
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("7")}
                >
                  7
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("8")}
                >
                  8
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("9")}
                >
                  9
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                  onClick={() => inputOperation("/")}
                >
                  ÷
                </Button>

                {/* Third Row */}
                <div></div>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("4")}
                >
                  4
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("5")}
                >
                  5
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("6")}
                >
                  6
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                  onClick={() => inputOperation("*")}
                >
                  ×
                </Button>

                {/* Fourth Row */}
                <div></div>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("1")}
                >
                  1
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("2")}
                >
                  2
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={() => inputNumber("3")}
                >
                  3
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                  onClick={() => inputOperation("-")}
                >
                  −
                </Button>

                {/* Fifth Row */}
                <div></div>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100 col-span-2"
                  onClick={() => inputNumber("0")}
                >
                  0
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold hover:bg-gray-100"
                  onClick={inputDecimal}
                >
                  .
                </Button>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                  onClick={() => inputOperation("+")}
                >
                  +
                </Button>

                {/* Sixth Row - Equals */}
                <div className="col-span-4"></div>
                <Button
                  variant="outline"
                  className="h-14 text-lg font-semibold bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                  onClick={performCalculation}
                >
                  =
                </Button>
              </div>

              {/* Keyboard Instructions */}
              <div className="mt-6 text-sm text-gray-600 text-center">
                <p>
                  💡 <strong>Keyboard shortcuts:</strong> Numbers (0-9), Operators (+, -, *, /), Enter/= (equals),
                  Escape/C (clear), Backspace (delete)
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* History Panel */}
        <div className="lg:col-span-1">
          <Card className="shadow-2xl h-full">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-xl font-bold text-gray-800">
                  <History className="w-5 h-5" />
                  History
                </CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setHistory([])}
                  className="text-red-600 hover:text-red-700"
                  disabled={history.length === 0}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px] px-6">
                {history.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No calculations yet</p>
                    <p className="text-sm">Your calculation history will appear here</p>
                  </div>
                ) : (
                  <div className="space-y-3 pb-6">
                    {history.map((entry) => (
                      <div
                        key={entry.id}
                        className="bg-gray-50 p-3 rounded-lg border hover:bg-gray-100 transition-colors cursor-pointer"
                        onClick={() => {
                          setDisplay(entry.result)
                          setWaitingForOperand(true)
                        }}
                      >
                        <div className="font-mono text-sm text-gray-600 mb-1">{entry.expression}</div>
                        <div className="font-mono font-bold text-lg text-gray-900">= {entry.result}</div>
                        <div className="text-xs text-gray-400 mt-1">{entry.timestamp.toLocaleTimeString()}</div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
