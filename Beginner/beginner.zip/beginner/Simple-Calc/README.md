# Basic calculator app

## Description

A minimalist calculator web app built with HTML, CSS, and JavaScript, offering basic arithmetic operations with a responsive and intuitive design.

## Features


Basic Arithmetic Operations: Supports addition, subtraction, multiplication, and division.

Frontend: HTML, CSS, JavaScript


## License

This project is licensed under the MIT License. See the LICENSE file for details.

## Contact

For questions or feedback, reach out to Akash Selvaraj or open an issue on GitHub.
