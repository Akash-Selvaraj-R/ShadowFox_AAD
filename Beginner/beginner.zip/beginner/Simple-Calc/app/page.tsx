"use client"

import AdvancedCalculator from "../components/advanced-calculator"

export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <AdvancedCalculator />
    </div>
  )
}
