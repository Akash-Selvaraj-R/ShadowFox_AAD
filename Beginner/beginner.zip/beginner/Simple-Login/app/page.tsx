"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertCircle } from "lucide-react"

export default function LoginPage() {
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  })
  const [errors, setErrors] = useState({
    username: "",
    password: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isFormVisible, setIsFormVisible] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Trigger form slide-in animation after component mounts
    const timer = setTimeout(() => {
      setIsFormVisible(true)
    }, 500)
    return () => clearTimeout(timer)
  }, [])

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))

    if (errors[field as keyof typeof errors]) {
      setErrors((prev) => ({
        ...prev,
        [field]: "",
      }))
    }
  }

  const validateForm = () => {
    const newErrors = {
      username: "",
      password: "",
    }

    if (!formData.username.trim()) {
      newErrors.username = "Username is required"
    }

    if (!formData.password.trim()) {
      newErrors.password = "Password is required"
    }

    setErrors(newErrors)
    return !newErrors.username && !newErrors.password
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    setTimeout(() => {
      sessionStorage.setItem("username", formData.username)
      router.push("/welcome")
      setIsSubmitting(false)
    }, 1000)
  }

  return (
    <div className="min-h-screen relative overflow-hidden bg-black">
      {/* Animated Background */}
      <div className="absolute inset-0">
        {/* Primary gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-black animate-gradient-shift"></div>

        {/* Floating animated elements */}
        <div className="absolute top-20 left-20 w-64 h-64 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full opacity-20 animate-float-slow blur-xl"></div>
        <div className="absolute bottom-32 right-16 w-96 h-96 bg-gradient-to-r from-pink-400 to-orange-500 rounded-full opacity-15 animate-float-reverse blur-2xl"></div>
        <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-r from-green-400 to-blue-500 rounded-full opacity-25 animate-pulse-slow blur-xl"></div>

        {/* Geometric shapes */}
        <div className="absolute top-1/4 right-1/4 w-32 h-32 border border-cyan-400 opacity-30 animate-spin-slow transform rotate-45"></div>
        <div className="absolute bottom-1/4 left-1/4 w-24 h-24 border-2 border-purple-400 opacity-40 animate-bounce-slow rounded-full"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6 md:p-8">
        <div className="flex items-center space-x-4">
          <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full animate-pulse-glow"></div>
          <h1 className="text-2xl md:text-3xl font-bold text-white tracking-wider animate-pulse-text">
            SOUL<span className="text-cyan-400">KEEPER</span>
          </h1>
        </div>
        <nav className="hidden md:flex space-x-8 text-sm text-gray-300 font-light tracking-wide">
          <a href="#" className="hover:text-cyan-400 transition-colors duration-300">
            ABOUT
          </a>
          <a href="#" className="hover:text-cyan-400 transition-colors duration-300">
            CONTACT
          </a>
        </nav>
      </header>

      {/* Main Content */}
      <div className="relative z-10 flex items-center justify-center min-h-[calc(100vh-120px)] px-4">
        <div
          className={`w-full max-w-md transform transition-all duration-1000 ease-out ${
            isFormVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
          }`}
        >
          {/* Login Form */}
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-8 shadow-2xl">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-2 tracking-wide">Welcome Back</h2>
              <p className="text-gray-300 font-light">Enter your credentials to continue</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-gray-200 font-medium">
                  Username
                </Label>
                <div className="relative">
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter your username"
                    value={formData.username}
                    onChange={(e) => handleInputChange("username", e.target.value)}
                    className={`bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-cyan-400 focus:ring-cyan-400/50 transition-all duration-300 hover:bg-white/15 ${
                      errors.username ? "border-red-400 focus:border-red-400 focus:ring-red-400/50" : ""
                    }`}
                  />
                  {errors.username && (
                    <div className="absolute -bottom-6 left-0 flex items-center space-x-1 text-red-400 text-sm">
                      <AlertCircle className="h-3 w-3" />
                      <span>{errors.username}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <Label htmlFor="password" className="text-gray-200 font-medium">
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => handleInputChange("password", e.target.value)}
                    className={`bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-cyan-400 focus:ring-cyan-400/50 transition-all duration-300 hover:bg-white/15 ${
                      errors.password ? "border-red-400 focus:border-red-400 focus:ring-red-400/50" : ""
                    }`}
                  />
                  {errors.password && (
                    <div className="absolute -bottom-6 left-0 flex items-center space-x-1 text-red-400 text-sm">
                      <AlertCircle className="h-3 w-3" />
                      <span>{errors.password}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-4">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-semibold py-3 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/25 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  {isSubmitting ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Authenticating...</span>
                    </div>
                  ) : (
                    "Sign In"
                  )}
                </Button>
              </div>
            </form>

            {/* Demo Credentials */}
            <div className="mt-8 text-center">
              <div className="inline-block px-4 py-2 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-lg border border-purple-400/30">
                <p className="text-xs text-gray-300 font-light tracking-wide">
                  <span className="text-cyan-400 font-medium">DEMO:</span> Use any username and password
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 text-center pb-6">
        <p className="text-gray-400 text-xs font-light tracking-wider">© 2024 SOULKEEPER. All rights reserved.</p>
      </footer>
    </div>
  )
}
