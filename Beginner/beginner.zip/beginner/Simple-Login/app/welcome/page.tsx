"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { User, LogOut, Sparkles } from "lucide-react"

export default function WelcomePage() {
  const [username, setUsername] = useState("")
  const [isVisible, setIsVisible] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const storedUsername = sessionStorage.getItem("username")
    if (!storedUsername) {
      router.push("/")
    } else {
      setUsername(storedUsername)
      setTimeout(() => setIsVisible(true), 300)
    }
  }, [router])

  const handleLogout = () => {
    sessionStorage.removeItem("username")
    router.push("/")
  }

  if (!username) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Redirecting...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen relative overflow-hidden bg-black">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-green-900 via-blue-900 to-black animate-gradient-shift"></div>
        <div className="absolute top-32 left-32 w-72 h-72 bg-gradient-to-r from-emerald-400 to-cyan-500 rounded-full opacity-20 animate-float-slow blur-xl"></div>
        <div className="absolute bottom-24 right-24 w-80 h-80 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full opacity-15 animate-float-reverse blur-2xl"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6 md:p-8">
        <div className="flex items-center space-x-4">
          <div className="w-8 h-8 bg-gradient-to-r from-emerald-400 to-cyan-500 rounded-full animate-pulse-glow"></div>
          <h1 className="text-2xl md:text-3xl font-bold text-white tracking-wider">
            SOUL<span className="text-emerald-400">KEEPER</span>
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="relative z-10 flex items-center justify-center min-h-[calc(100vh-120px)] px-4">
        <div
          className={`text-center transform transition-all duration-1000 ease-out ${
            isVisible ? "translate-y-0 opacity-100 scale-100" : "translate-y-8 opacity-0 scale-95"
          }`}
        >
          {/* Welcome Card */}
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-12 shadow-2xl max-w-lg">
            {/* Success Icon */}
            <div className="mx-auto w-20 h-20 bg-gradient-to-r from-emerald-400 to-cyan-500 rounded-full flex items-center justify-center mb-8 animate-pulse-glow">
              <User className="w-10 h-10 text-white" />
            </div>

            {/* Welcome Message */}
            <h2 className="text-4xl font-bold text-white mb-4 tracking-wide">
              Welcome, <span className="text-emerald-400">{username}</span>!
            </h2>

            <p className="text-gray-300 text-lg mb-8 font-light">
              You have successfully authenticated and gained access to your account.
            </p>

            {/* Success Indicator */}
            <div className="mb-8 p-4 bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 rounded-xl border border-emerald-400/30">
              <div className="flex items-center justify-center space-x-2 text-emerald-400">
                <Sparkles className="w-5 h-5 animate-pulse" />
                <span className="font-medium">Authentication Successful</span>
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <p className="text-xs text-gray-400 mt-2 font-light">Session active for: {username}</p>
            </div>

            {/* Logout Button */}
            <Button
              onClick={handleLogout}
              className="bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white font-semibold py-3 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
