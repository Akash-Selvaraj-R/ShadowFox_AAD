"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Heart, MessageCircle, Share, LogOut, Loader2 } from "lucide-react"
import Image from "next/image"

// Simulated user profile data
const userProfile = {
  name: "Akash ShadowFox",
  profilePic: "/placeholder.svg?height=100&width=100",
  coverPhoto: "/placeholder.svg?height=200&width=800",
}

interface Post {
  id: number
  text: string
  time: Date
  likes: number
  comments: number
}

export default function FacebookLoginSim() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [loading, setLoading] = useState(false)
  const [posts, setPosts] = useState<Post[]>([])
  const [newPost, setNewPost] = useState("")

  // Simulate login with 1 second delay
  const handleLogin = async () => {
    setLoading(true)
    setTimeout(() => {
      setLoggedIn(true)
      setLoading(false)
    }, 1000)
  }

  // Handle logout
  const handleLogout = () => {
    setLoggedIn(false)
    setPosts([])
    setNewPost("")
  }

  // Handle posting
  const handlePost = () => {
    if (newPost.trim()) {
      const post: Post = {
        id: Date.now(),
        text: newPost,
        time: new Date(),
        likes: Math.floor(Math.random() * 50),
        comments: Math.floor(Math.random() * 20),
      }
      setPosts([post, ...posts])
      setNewPost("")
    }
  }

  // Format time for posts
  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m`
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h`
    return `${Math.floor(diffInMinutes / 1440)}d`
  }

  // Login Screen
  if (!loggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-600 to-blue-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center space-y-4">
            <div className="text-4xl font-bold text-blue-600">facebook</div>
            <p className="text-gray-600">Connect with friends and the world around you on Facebook.</p>
          </CardHeader>
          <CardContent className="space-y-4">
            {loading ? (
              <Button disabled className="w-full bg-blue-600 hover:bg-blue-700">
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Logging in...
              </Button>
            ) : (
              <Button
                onClick={handleLogin}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3"
              >
                <svg className="mr-2 h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
                Continue with Facebook
              </Button>
            )}
            <div className="text-center text-sm text-gray-500">
              This is a simulated login - no real authentication required! 🎭
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Main Dashboard
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="text-2xl font-bold text-blue-600">facebook</div>
          <Button onClick={handleLogout} variant="outline" className="flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </header>

      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {/* Profile Section */}
        <Card>
          <div className="relative">
            <Image
              src={userProfile.coverPhoto || "/placeholder.svg"}
              alt="Cover"
              width={800}
              height={200}
              className="w-full h-48 object-cover rounded-t-lg"
            />
            <Avatar className="absolute -bottom-12 left-6 w-24 h-24 border-4 border-white">
              <AvatarImage src={userProfile.profilePic || "/placeholder.svg"} alt={userProfile.name} />
              <AvatarFallback className="text-2xl">AS</AvatarFallback>
            </Avatar>
          </div>
          <CardContent className="pt-16 pb-4">
            <h1 className="text-2xl font-bold">{userProfile.name}</h1>
            <p className="text-gray-600">Welcome back! 👋</p>
          </CardContent>
        </Card>

        {/* Post Creation */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Avatar>
                <AvatarImage src={userProfile.profilePic || "/placeholder.svg"} alt={userProfile.name} />
                <AvatarFallback>AS</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-3">
                <Input
                  placeholder="What's on your mind, Akash?"
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="border-none bg-gray-100 text-lg placeholder:text-gray-500"
                />
                <div className="flex justify-end">
                  <Button onClick={handlePost} disabled={!newPost.trim()} className="bg-blue-600 hover:bg-blue-700">
                    Post 🎉
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts Feed */}
        {posts.length > 0 && (
          <div className="space-y-4">
            {posts.map((post) => (
              <Card key={post.id}>
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <Avatar>
                      <AvatarImage src={userProfile.profilePic || "/placeholder.svg"} alt={userProfile.name} />
                      <AvatarFallback>AS</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-semibold">{userProfile.name}</h3>
                        <span className="text-gray-500 text-sm">·</span>
                        <span className="text-gray-500 text-sm">{formatTime(post.time)}</span>
                      </div>
                      <p className="mt-2 text-gray-800">{post.text}</p>

                      <Separator className="my-3" />

                      <div className="flex items-center justify-between text-gray-500">
                        <div className="flex items-center space-x-1">
                          <span className="text-sm">{post.likes} 👍</span>
                          <span className="text-sm">{post.comments} 💬</span>
                        </div>
                      </div>

                      <Separator className="my-3" />

                      <div className="flex items-center justify-around">
                        <Button variant="ghost" className="flex-1 text-gray-600 hover:bg-gray-100">
                          <Heart className="mr-2 h-4 w-4" />
                          Like
                        </Button>
                        <Button variant="ghost" className="flex-1 text-gray-600 hover:bg-gray-100">
                          <MessageCircle className="mr-2 h-4 w-4" />
                          Comment
                        </Button>
                        <Button variant="ghost" className="flex-1 text-gray-600 hover:bg-gray-100">
                          <Share className="mr-2 h-4 w-4" />
                          Share
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {posts.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No posts yet!</h3>
              <p className="text-gray-500">Share your first post to get started.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
