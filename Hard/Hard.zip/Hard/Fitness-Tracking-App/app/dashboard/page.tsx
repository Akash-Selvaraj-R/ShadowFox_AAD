"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, BarChart3, TrendingUp, Award, Target } from "lucide-react"
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface Goals {
  steps: number
  exerciseMinutes: number
  waterLiters: number
  caloriesBurned: number
}

interface ActivityData {
  steps: number
  exerciseMinutes: number
  waterLiters: number
  caloriesBurned: number
  date: string
}

interface ProgressData {
  metric: string
  current: number
  goal: number
  percentage: number
  color: string
}

export default function DashboardPage() {
  const [goals, setGoals] = useState<Goals>({
    steps: 10000,
    exerciseMinutes: 30,
    waterLiters: 2.5,
    caloriesBurned: 500,
  })
  const [todayActivity, setTodayActivity] = useState<ActivityData>({
    steps: 0,
    exerciseMinutes: 0,
    waterLiters: 0,
    caloriesBurned: 0,
    date: new Date().toISOString().split("T")[0],
  })

  useEffect(() => {
    // Load goals
    const savedGoals = localStorage.getItem("fitnessGoals")
    if (savedGoals) {
      setGoals(JSON.parse(savedGoals))
    }

    // Load today's activity
    const today = new Date().toISOString().split("T")[0]
    const savedActivity = localStorage.getItem(`fitnessActivity_${today}`)
    if (savedActivity) {
      setTodayActivity(JSON.parse(savedActivity))
    }
  }, [])

  const getMotivationalMessage = (percentage: number): string => {
    if (percentage >= 100) return "Goal Achieved! 🎉"
    if (percentage >= 75) return "Almost there! Keep it up 💪"
    if (percentage >= 50) return "You're halfway there 🔥"
    if (percentage >= 25) return "Good start! Keep going 🚀"
    return "You can do this! Start now 💫"
  }

  const progressData: ProgressData[] = [
    {
      metric: "Steps",
      current: todayActivity.steps,
      goal: goals.steps,
      percentage: Math.min((todayActivity.steps / goals.steps) * 100, 100),
      color: "#3b82f6",
    },
    {
      metric: "Exercise",
      current: todayActivity.exerciseMinutes,
      goal: goals.exerciseMinutes,
      percentage: Math.min((todayActivity.exerciseMinutes / goals.exerciseMinutes) * 100, 100),
      color: "#10b981",
    },
    {
      metric: "Water",
      current: todayActivity.waterLiters,
      goal: goals.waterLiters,
      percentage: Math.min((todayActivity.waterLiters / goals.waterLiters) * 100, 100),
      color: "#06b6d4",
    },
    {
      metric: "Calories",
      current: todayActivity.caloriesBurned,
      goal: goals.caloriesBurned,
      percentage: Math.min((todayActivity.caloriesBurned / goals.caloriesBurned) * 100, 100),
      color: "#f59e0b",
    },
  ]

  const overallProgress = progressData.reduce((sum, item) => sum + item.percentage, 0) / progressData.length
  const completedGoals = progressData.filter((item) => item.percentage >= 100).length

  const pieData = progressData.map((item) => ({
    name: item.metric,
    value: item.current,
    goal: item.goal,
    percentage: item.percentage,
    color: item.color,
  }))

  const barData = progressData.map((item) => ({
    metric: item.metric,
    current: item.current,
    goal: item.goal,
    percentage: item.percentage,
  }))

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Link>
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" asChild>
              <Link href="/set-goals">
                <Target className="h-4 w-4 mr-2" />
                Edit Goals
              </Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/log-activity">Log Activity</Link>
            </Button>
          </div>
        </div>

        <div className="text-center mb-8">
          <BarChart3 className="h-12 w-12 text-purple-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Fitness Dashboard</h1>
          <p className="text-lg text-gray-600">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>

        {/* Overall Progress Card */}
        <Card className="mb-6">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center">
              <Award className="h-6 w-6 mr-2 text-yellow-500" />
              Today's Overall Progress
            </CardTitle>
            <CardDescription className="text-2xl font-bold text-purple-600">
              {overallProgress.toFixed(1)}% Complete
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-4">
              <p className="text-lg font-medium text-gray-800">{getMotivationalMessage(overallProgress)}</p>
              <p className="text-sm text-gray-600 mt-2">
                {completedGoals} of {progressData.length} goals completed
              </p>
            </div>
            <Progress value={overallProgress} className="h-3" />
          </CardContent>
        </Card>

        {/* Individual Progress Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {progressData.map((item) => (
            <Card key={item.metric}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{item.metric}</CardTitle>
                <CardDescription>
                  {item.metric === "Water"
                    ? `${item.current}L / ${item.goal}L`
                    : item.metric === "Exercise"
                      ? `${item.current} / ${item.goal} min`
                      : `${item.current.toLocaleString()} / ${item.goal.toLocaleString()}`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Progress value={item.percentage} className="h-2 mb-2" />
                <p className="text-sm font-medium" style={{ color: item.color }}>
                  {item.percentage.toFixed(1)}% Complete
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                Progress Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={barData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="metric" />
                  <YAxis />
                  <Tooltip
                    formatter={(value, name) => [
                      name === "current" ? `${value} (Current)` : `${value} (Goal)`,
                      name === "current" ? "Current" : "Goal",
                    ]}
                  />
                  <Bar dataKey="current" fill="#8884d8" />
                  <Bar dataKey="goal" fill="#82ca9d" opacity={0.6} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Goal Completion</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={120}
                    paddingAngle={5}
                    dataKey="percentage"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${Number(value).toFixed(1)}%`, "Progress"]} />
                </PieChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-2 gap-2 mt-4">
                {pieData.map((entry) => (
                  <div key={entry.name} className="flex items-center">
                    <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: entry.color }} />
                    <span className="text-sm">{entry.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Stats */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Quick Stats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-blue-600">{todayActivity.steps.toLocaleString()}</p>
                <p className="text-sm text-gray-600">Steps Today</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">{todayActivity.exerciseMinutes}</p>
                <p className="text-sm text-gray-600">Minutes Exercised</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-cyan-600">{todayActivity.waterLiters}L</p>
                <p className="text-sm text-gray-600">Water Consumed</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-yellow-600">{todayActivity.caloriesBurned}</p>
                <p className="text-sm text-gray-600">Calories Burned</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
