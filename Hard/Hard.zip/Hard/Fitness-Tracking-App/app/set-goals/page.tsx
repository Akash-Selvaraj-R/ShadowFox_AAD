"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Target, Save } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Goals {
  steps: number
  exerciseMinutes: number
  waterLiters: number
  caloriesBurned: number
}

export default function SetGoalsPage() {
  const [goals, setGoals] = useState<Goals>({
    steps: 10000,
    exerciseMinutes: 30,
    waterLiters: 2.5,
    caloriesBurned: 500,
  })
  const { toast } = useToast()

  useEffect(() => {
    const savedGoals = localStorage.getItem("fitnessGoals")
    if (savedGoals) {
      setGoals(JSON.parse(savedGoals))
    }
  }, [])

  const handleSave = () => {
    localStorage.setItem("fitnessGoals", JSON.stringify(goals))
    toast({
      title: "Goals Saved! 🎯",
      description: "Your daily fitness goals have been updated successfully.",
    })
  }

  const handleInputChange = (field: keyof Goals, value: string) => {
    const numValue = Number.parseFloat(value) || 0
    setGoals((prev) => ({ ...prev, [field]: numValue }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="sm" asChild className="mr-4">
            <Link href="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Link>
          </Button>
        </div>

        <Card>
          <CardHeader className="text-center">
            <Target className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <CardTitle className="text-2xl">Set Your Daily Goals</CardTitle>
            <CardDescription>Define your daily fitness targets to stay motivated and track progress</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="steps">Daily Steps Goal</Label>
                <Input
                  id="steps"
                  type="number"
                  value={goals.steps}
                  onChange={(e) => handleInputChange("steps", e.target.value)}
                  placeholder="e.g., 10000"
                />
                <p className="text-sm text-gray-500">Recommended: 8,000-12,000 steps per day</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="exercise">Exercise Minutes Goal</Label>
                <Input
                  id="exercise"
                  type="number"
                  value={goals.exerciseMinutes}
                  onChange={(e) => handleInputChange("exerciseMinutes", e.target.value)}
                  placeholder="e.g., 30"
                />
                <p className="text-sm text-gray-500">Recommended: 30-60 minutes per day</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="water">Water Intake Goal (Liters)</Label>
                <Input
                  id="water"
                  type="number"
                  step="0.1"
                  value={goals.waterLiters}
                  onChange={(e) => handleInputChange("waterLiters", e.target.value)}
                  placeholder="e.g., 2.5"
                />
                <p className="text-sm text-gray-500">Recommended: 2-3 liters per day</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="calories">Calories Burned Goal</Label>
                <Input
                  id="calories"
                  type="number"
                  value={goals.caloriesBurned}
                  onChange={(e) => handleInputChange("caloriesBurned", e.target.value)}
                  placeholder="e.g., 500"
                />
                <p className="text-sm text-gray-500">Recommended: 300-800 calories per day</p>
              </div>
            </div>

            <div className="flex gap-4 pt-4">
              <Button onClick={handleSave} className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                Save Goals
              </Button>
              <Button variant="outline" asChild>
                <Link href="/dashboard">View Dashboard</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 bg-white rounded-lg p-4 shadow-sm">
          <h3 className="font-medium text-gray-900 mb-2">💡 Goal Setting Tips</h3>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Start with achievable goals and gradually increase them</li>
            <li>• Make your goals specific and measurable</li>
            <li>• Consider your current fitness level and lifestyle</li>
            <li>• Review and adjust your goals weekly</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
