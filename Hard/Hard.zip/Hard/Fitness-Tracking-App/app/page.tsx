import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, Target, BarChart3 } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8 pt-8">
          <div className="flex items-center justify-center mb-4">
            <Activity className="h-12 w-12 text-blue-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">FitTracker</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Track your daily fitness goals and stay motivated on your wellness journey
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <Target className="h-12 w-12 text-green-600 mx-auto mb-2" />
              <CardTitle>Set Goals</CardTitle>
              <CardDescription>
                Define your daily fitness targets for steps, exercise, water intake, and more
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full">
                <Link href="/set-goals">Set Your Goals</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <Activity className="h-12 w-12 text-blue-600 mx-auto mb-2" />
              <CardTitle>Log Activity</CardTitle>
              <CardDescription>Record your daily activities and track your progress throughout the day</CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full">
                <Link href="/log-activity">Log Today's Activity</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow md:col-span-2 lg:col-span-1">
            <CardHeader className="text-center">
              <BarChart3 className="h-12 w-12 text-purple-600 mx-auto mb-2" />
              <CardTitle>Dashboard</CardTitle>
              <CardDescription>View your progress with interactive charts and motivational insights</CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full">
                <Link href="/dashboard">View Dashboard</Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-md">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Why Track Your Fitness?</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Stay Motivated</h3>
              <p className="text-gray-600">
                Visual progress tracking helps maintain motivation and builds healthy habits over time.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Achieve Goals</h3>
              <p className="text-gray-600">
                Setting specific, measurable goals increases your likelihood of success by 42%.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Build Consistency</h3>
              <p className="text-gray-600">
                Daily tracking creates accountability and helps establish lasting fitness routines.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Monitor Health</h3>
              <p className="text-gray-600">
                Regular activity tracking provides insights into your overall health and wellness trends.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
