"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Activity, Save, Calendar } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ActivityData {
  steps: number
  exerciseMinutes: number
  waterLiters: number
  caloriesBurned: number
  date: string
}

export default function LogActivityPage() {
  const [activity, setActivity] = useState<ActivityData>({
    steps: 0,
    exerciseMinutes: 0,
    waterLiters: 0,
    caloriesBurned: 0,
    date: new Date().toISOString().split("T")[0],
  })
  const { toast } = useToast()

  useEffect(() => {
    const today = new Date().toISOString().split("T")[0]
    const savedActivity = localStorage.getItem(`fitnessActivity_${today}`)
    if (savedActivity) {
      setActivity(JSON.parse(savedActivity))
    } else {
      setActivity((prev) => ({ ...prev, date: today }))
    }
  }, [])

  const handleSave = () => {
    const today = new Date().toISOString().split("T")[0]
    localStorage.setItem(`fitnessActivity_${today}`, JSON.stringify(activity))

    // Also save to a general activities log
    const allActivities = JSON.parse(localStorage.getItem("allFitnessActivities") || "[]")
    const existingIndex = allActivities.findIndex((a: ActivityData) => a.date === today)

    if (existingIndex >= 0) {
      allActivities[existingIndex] = activity
    } else {
      allActivities.push(activity)
    }

    localStorage.setItem("allFitnessActivities", JSON.stringify(allActivities))

    toast({
      title: "Activity Logged! 📊",
      description: "Your daily activity has been recorded successfully.",
    })
  }

  const handleInputChange = (field: keyof Omit<ActivityData, "date">, value: string) => {
    const numValue = Number.parseFloat(value) || 0
    setActivity((prev) => ({ ...prev, [field]: numValue }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 p-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="sm" asChild className="mr-4">
            <Link href="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Link>
          </Button>
        </div>

        <Card>
          <CardHeader className="text-center">
            <Activity className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <CardTitle className="text-2xl">Log Today's Activity</CardTitle>
            <CardDescription className="flex items-center justify-center">
              <Calendar className="h-4 w-4 mr-2" />
              {new Date().toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="steps">Steps Taken</Label>
                <Input
                  id="steps"
                  type="number"
                  value={activity.steps}
                  onChange={(e) => handleInputChange("steps", e.target.value)}
                  placeholder="e.g., 8500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="exercise">Exercise Minutes</Label>
                <Input
                  id="exercise"
                  type="number"
                  value={activity.exerciseMinutes}
                  onChange={(e) => handleInputChange("exerciseMinutes", e.target.value)}
                  placeholder="e.g., 45"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="water">Water Consumed (Liters)</Label>
                <Input
                  id="water"
                  type="number"
                  step="0.1"
                  value={activity.waterLiters}
                  onChange={(e) => handleInputChange("waterLiters", e.target.value)}
                  placeholder="e.g., 2.2"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="calories">Calories Burned</Label>
                <Input
                  id="calories"
                  type="number"
                  value={activity.caloriesBurned}
                  onChange={(e) => handleInputChange("caloriesBurned", e.target.value)}
                  placeholder="e.g., 420"
                />
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-2">Quick Add Options</h3>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setActivity((prev) => ({ ...prev, steps: prev.steps + 1000 }))}
                >
                  +1000 Steps
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setActivity((prev) => ({ ...prev, exerciseMinutes: prev.exerciseMinutes + 15 }))}
                >
                  +15 Min Exercise
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setActivity((prev) => ({ ...prev, waterLiters: prev.waterLiters + 0.5 }))}
                >
                  +0.5L Water
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setActivity((prev) => ({ ...prev, caloriesBurned: prev.caloriesBurned + 100 }))}
                >
                  +100 Calories
                </Button>
              </div>
            </div>

            <div className="flex gap-4 pt-4">
              <Button onClick={handleSave} className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                Save Activity
              </Button>
              <Button variant="outline" asChild>
                <Link href="/dashboard">View Progress</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
